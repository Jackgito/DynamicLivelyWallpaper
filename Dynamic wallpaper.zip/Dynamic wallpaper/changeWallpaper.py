import os
import time
import datetime

# This is used to prevent unnecessary calls
dayOrNight = "Unknown"

while(True):
    current_time = datetime.datetime.now()
    if (current_time.hour >= 20 or current_time.hour < 6) and (dayOrNight == "Unknown" or dayOrNight == "Day"):
        os.startfile (r"changeGamma2.lnk")
        dayOrNight = "Night"
        #print(dayOrNight)
    elif (current_time.hour < 20 and current_time.hour > 6) and (dayOrNight == "Unknown" or dayOrNight == "Night"):
        os.startfile (r"changeGamma.lnk")
        dayOrNight = "Day"
        #print(dayOrNight)
    time.sleep(1)
